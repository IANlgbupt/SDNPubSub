package edu.bupt.wangfu.module.wsnMgr.util.soap.wsn;

import java.util.HashMap;

public class Instance {
    public static HashMap<String,String> TPmap=new HashMap<>();
}
